/**
 * @authors Avik De <avikde@gmail.com>
   @modified baidhowi

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */
#include "variant.h"
#include "types.h"
#include "USARTClass.h"
#include "adc.h"


const uint8_t A0 = 64;
const uint8_t A1 = 65;
const uint8_t A2 = 66;
const uint8_t A3 = 67;
const uint8_t A4 = 68;
const uint8_t A5 = 69;
const uint8_t A6 = 70;
const uint8_t A7 = 71;
const uint8_t A8 = 72;
const uint8_t A9 = 73;
const uint8_t A10 = 74;
const uint8_t A11 = 75;
const uint8_t A12 = 76;
const uint8_t A13 = 77;
const uint8_t A14 = 78;
const uint8_t A15 = 79;


const uint8_t PA9 = 26;
const uint8_t PA10 = 28;
const uint8_t PA2 = 70;
const uint8_t PA3 = 71;
const uint8_t PC10 = 29;
const uint8_t PC11 = 31;
const uint8_t PC6 = 2;
const uint8_t PC7 = 3;

// pin 12C
const uint8_t PB7 = 33;
const uint8_t PB6 = 35;
const uint8_t PB10 = 11;
const uint8_t PB11 = 9;
const uint8_t PA8 = 45;
const uint8_t PC9 = 1;

// LED
const uint8_t LED_1 = 6;
const uint8_t LED_2 = 4;
const uint8_t LED_3 = 5;
const uint8_t LED_4 = 7;



PinInfo PIN_MAP[] = {
  //GPIO,PORT, ADC_CH,      AF,   TIMER,  TIM_CH,adcconfin, ioconf,
  {GPIOC,  7, NOT_SET,		 3,  TIMER8,       2, NOT_SET, NOT_SET},  //0
  {GPIOC,  9, NOT_SET,		 3,  TIMER8,       4, NOT_SET, NOT_SET},  //1 
  {GPIOC,  6, NOT_SET,		 3,  TIMER8,       1, NOT_SET, NOT_SET},  //2
  {GPIOC,  8, NOT_SET,		 3,  TIMER8,       3, NOT_SET, NOT_SET},  //3
  {GPIOD, 13, NOT_SET,		 2,  TIMER4,       2, NOT_SET, NOT_SET},  //4
  {GPIOD, 15, NOT_SET,		 2,  TIMER4,       4, NOT_SET, NOT_SET},  //5
  {GPIOD, 12, NOT_SET,		 2,  TIMER4,       1, NOT_SET, NOT_SET},  //6
  {GPIOD, 14, NOT_SET,		 2,  TIMER4,       3, NOT_SET, NOT_SET},  //7
  {GPIOB,  3, NOT_SET,		 1,  TIMER2,       2, NOT_SET, NOT_SET},  //8
  {GPIOB, 11, NOT_SET,		 1,  TIMER2,       4, NOT_SET, NOT_SET},  //9
  {GPIOA, 15, NOT_SET,		 1,  TIMER2,       1, NOT_SET, NOT_SET},  //10
  {GPIOB, 10, NOT_SET,		 1,  TIMER2,       3, NOT_SET, NOT_SET},  //11
  {GPIOB,  5, NOT_SET,		 2,  TIMER3,       2, NOT_SET, NOT_SET},  //12
  {GPIOB,  4, NOT_SET,		 2,  TIMER3,       1, NOT_SET, NOT_SET},  //13
  {GPIOE, 14, NOT_SET,		 1,  TIMER1,       4, NOT_SET, NOT_SET},  //14
  {GPIOE, 13, NOT_SET,		 1,  TIMER1,       3, NOT_SET, NOT_SET},  //15

  {GPIOE, 11, NOT_SET,		 3,  TIMER1,       2, NOT_SET, NOT_SET},  //16
  {GPIOB,  8, NOT_SET,		 3, TIMER10,       1, NOT_SET, NOT_SET},  //17 
  {GPIOE,  9, NOT_SET,		 3,  TIMER1,       1, NOT_SET, NOT_SET},  //18
  {GPIOB,  9, NOT_SET,		 3, TIMER11,       1, NOT_SET, NOT_SET},  //19
  {GPIOE,  1, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //20
  {GPIOE,  2, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //21
  {GPIOD,  5, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //22
  {GPIOB, 13, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //23
  {GPIOD,  6, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //24
  {GPIOB, 14, NOT_SET,		 9, TIMER12,       1, NOT_SET, NOT_SET},  //25
  {GPIOA,  9, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //26
  {GPIOB, 15, NOT_SET,		 9, TIMER12,       2, NOT_SET, NOT_SET},  //27
  {GPIOA, 10, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //28
  {GPIOC, 10, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //29
  {GPIOC, 12, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //30
  {GPIOC, 11, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //31

  {GPIOD,  2, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //32
  {GPIOB,  7, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //33
  {GPIOD,  8, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //34
  {GPIOB,  6, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //35
  {GPIOD,  9, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //36
  {GPIOA, 14, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //37
  {GPIOD,  7, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //38
  {GPIOA, 11, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //39
  {GPIOA, 12, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //40
  {GPIOD,  1, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //41
  {GPIOA, 13, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //42
  {GPIOD,  0, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //43
  {GPIOB, 12, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //44
  {GPIOA,  8, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //45
  {GPIOD, 10, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //46
  {GPIOD, 11, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //47

  {GPIOD,  3, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //48
  {GPIOD,  4, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //49
  {GPIOE,  0, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //50
  {GPIOE,  5, NOT_SET,       3,  TIMER9,       1, NOT_SET, NOT_SET},  //51
  {GPIOE,  6, NOT_SET,       3,  TIMER9,       2, NOT_SET, NOT_SET},  //52
  {GPIOC, 13, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //53
  {GPIOC, 14, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //54
  {GPIOC, 15, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //55
  {GPIOE, 10, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //56
  {GPIOE,  7, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //57
  {GPIOE, 15, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //58
  {GPIOB,  2, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //59
  {GPIOE,  8, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //60
  {GPIOE, 12, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //61
  {GPIOE,  3, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //62
  {GPIOE,  4, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //63

  {GPIOC,  0,      10, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //64
  {GPIOC,  1,      11, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //65 
  {GPIOC,  2,      12, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //66
  {GPIOC,  3,      13, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //67
  {GPIOA,  0,       0,		 2,  TIMER5,       1, NOT_SET, NOT_SET},  //68
  {GPIOA,  1,       1,		 2,  TIMER5,       2, NOT_SET, NOT_SET},  //69
  {GPIOA,  2,       2,		 2,  TIMER5,       3, NOT_SET, NOT_SET},  //70
  {GPIOA,  3,       3,		 2,  TIMER5,       4, NOT_SET, NOT_SET},  //71
  {GPIOA,  4,       4, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //72
  {GPIOA,  5,       5, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //73
  {GPIOA,  6,       6,		 9, TIMER13,       1, NOT_SET, NOT_SET},  //74
  {GPIOA,  7,       7,		 9, TIMER14,       1, NOT_SET, NOT_SET},  //75
  {GPIOC,  4,      14, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //76
  {GPIOC,  5,      15, NOT_SET, NOT_SET, NOT_SET, NOT_SET, NOT_SET},  //77
  {GPIOB,  0,       8,		 2,  TIMER3,       4, NOT_SET, NOT_SET},  //78
  {GPIOB,  1,       9,		 2,  TIMER3,       3, NOT_SET, NOT_SET},  //79
};

const uint8_t TIMER2 = 0;
const uint8_t TIMER5 = 1;
const uint8_t TIMER3 = 2;
const uint8_t TIMER4 = 3;
const uint8_t TIMER1 = 4;
const uint8_t TIMER8 = 5;
const uint8_t TIMER9 = 6;
const uint8_t TIMER12 = 7;
const uint8_t TIMER10 = 8;
const uint8_t TIMER11 = 9;
const uint8_t TIMER13 = 10;
const uint8_t TIMER14 = 11;
const uint8_t TIMER6 = 12;
const uint8_t TIMER7 = 13;

TimerChannelData timer2ch[4] = {
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0}
};
TimerChannelData timer5ch[4] = {
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0}
};

TimerChannelData timer3ch[4] = {
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0}
};
TimerChannelData timer4ch[4] = {
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0}
};
TimerChannelData timer1ch[4] = {
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0}
};
TimerChannelData timer8ch[4] = {
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0}
};
TimerChannelData timer9ch[2] = {
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0}
};
TimerChannelData timer12ch[2] = {
  {0, false, 0, 0, 0, 0},
  {0, false, 0, 0, 0, 0}
};

TimerInfo TIMER_MAP[] = {
  {TIM2, TIM2_IRQn, 1000, 0, timer2ch},
  {TIM5, TIM5_IRQn, 1000, 0, timer5ch},
  {TIM3, TIM3_IRQn, 1000, 0, timer3ch},
  {TIM4, TIM4_IRQn, 1000, 0, timer4ch},
  {TIM1, TIM1_CC_IRQn, 1000, 0, timer1ch},
  {TIM8, TIM8_CC_IRQn, 1000, 0, timer8ch},
  {TIM9, TIM1_BRK_TIM9_IRQn, 1000, 0, timer9ch},
  {TIM12, TIM8_BRK_TIM12_IRQn, 1000, 0, timer12ch},
  {TIM10, TIM1_UP_TIM10_IRQn, 1000, 0, (TimerChannelData *)0},
  {TIM11, TIM1_TRG_COM_TIM11_IRQn, 1000, 0, (TimerChannelData *)0},
  {TIM13, TIM8_UP_TIM13_IRQn, 1000, 0, (TimerChannelData *)0},
  {TIM14, TIM8_TRG_COM_TIM14_IRQn, 1000, 0, (TimerChannelData *)0},
  {TIM6, TIM6_DAC_IRQn, 1000, 0, (TimerChannelData *)0},
  {TIM7, TIM7_IRQn, 1000, 0, (TimerChannelData *)0},
};



// Use the 3 basic timers and two others
TimebaseChannel TIMEBASE_MAP[] = {
  {.timer = NOT_SET, .isr = 0}, // 0
  {.timer = NOT_SET, .isr = 0}, // 1
  {.timer = NOT_SET, .isr = 0}, // 2
  {.timer = NOT_SET, .isr = 0}, // 3
  {.timer = NOT_SET, .isr = 0}, // 4
  {.timer = NOT_SET, .isr = 0}, // 5
  {.timer = NOT_SET, .isr = 0}, // 6
  {.timer = NOT_SET, .isr = 0}, // 7
  {.timer = NOT_SET, .isr = 0}, // 8
  {.timer = NOT_SET, .isr = 0}, // 9
  {.timer = NOT_SET, .isr = 0}, // 10
  {.timer = NOT_SET, .isr = 0}, // 11
  {.timer = NOT_SET, .isr = 0}, // 12
  {.timer = NOT_SET, .isr = 0}, // 13
  {.timer = NOT_SET, .isr = 0} //  14
};

// Serial
USARTInfo USART_MAP[6] = {
  { USART1, USART1_IRQn, 26, 28 },
  { USART2, USART2_IRQn, 22, 24 },
  { USART3, USART3_IRQn, 34, 36 },
  { UART4, UART4_IRQn, 29, 31 },
  { UART5, UART5_IRQn, 30, 32 },
  { USART6, USART6_IRQn, 2, 0 }
};

USARTClass Serial1(&USART_MAP[0]);
USARTClass Serial2(&USART_MAP[1]);
USARTClass Serial3(&USART_MAP[2]);
USARTClass Serial4(&USART_MAP[3]);
USARTClass Serial5(&USART_MAP[4]);
USARTClass Serial6(&USART_MAP[5]);

bool isTimer32Bit(uint8_t tim) {
  return (tim < TIMER3);
}

uint8_t numChannelsInTimer(uint8_t tim) {
  if (tim < TIMER9)
    return 4;
  else if (tim < TIMER10)
    return 2;
  else if (tim < TIMER6)
    return 1;
  else
    return 0;
}

bool isAnalogPin(uint8_t pin) {
  return (PIN_MAP[pin].adcChannel != NOT_SET);
}

void variantInit() {
  TIMEBASE_MAP[1].timer = TIMER1;
  TIMEBASE_MAP[2].timer = TIMER2;
  TIMEBASE_MAP[3].timer = TIMER3;
  TIMEBASE_MAP[4].timer = TIMER4;
  TIMEBASE_MAP[5].timer = TIMER5;
  TIMEBASE_MAP[6].timer = TIMER6;
  TIMEBASE_MAP[7].timer = TIMER7;
  TIMEBASE_MAP[8].timer = TIMER8;
  TIMEBASE_MAP[9].timer = TIMER9;
  TIMEBASE_MAP[10].timer = TIMER10;
  TIMEBASE_MAP[11].timer = TIMER11;
  TIMEBASE_MAP[12].timer = TIMER12;
  TIMEBASE_MAP[13].timer = TIMER13;
  TIMEBASE_MAP[14].timer = TIMER14;

  // GPIO
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOB, ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOC, ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOD, ENABLE);
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOE, ENABLE);
  // SYSCFG - needed for EXTI
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_SYSCFG, ENABLE);

  // Timer clocks
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM6, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM7, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM12, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM13, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM14, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM9, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM10, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM11, ENABLE);

  // USART
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART1, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART2, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_USART3, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART4, ENABLE);
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_UART5, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_USART6, ENABLE);

  // ADC(s)
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC1, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC2, ENABLE);
  RCC_APB2PeriphClockCmd(RCC_APB2Periph_ADC3, ENABLE);
  // adcCommonInit();
  adcInit(ADC1);
  adcInit(ADC2);
  adcInit(ADC3);
}


