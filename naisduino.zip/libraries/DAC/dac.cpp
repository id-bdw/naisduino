/**
 * @authors baidhowi

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */
#include "dac.h"
#include "stm32f4xx_dac.h"


#if defined(STM32F40_41xxx)
uint8_t dac_ch1 = 72;   //PE9
uint8_t dac_ch2 = 73;	 //PE11
#endif

typedef enum {
  SINGLE_DAC1 = 0, // 
  SINGLE_DAC2,     // 
}DAC_MODE_t;

DAC_MODE_t mode_dac;

void P_DAC1_InitIO(void);
void P_DAC1_InitDAC(void);
void P_DAC2_InitIO(void);
void P_DAC2_InitDAC(void);
void DAC_SetDAC2(uint16_t val);
void DAC_SetDAC1(uint16_t val);

// Public Methods //////////////////////////////////////////////////////////////
dac::dac(uint8_t dac_mode){
	if(dac_mode==0){
		mode_dac = SINGLE_DAC1;
	}	
	else if(dac_mode==1){
		mode_dac = SINGLE_DAC2;
	}
}

void dac::begin() {
  DAC_InitTypeDef  DAC_InitStructure;
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

  // DAC-Config
  DAC_InitStructure.DAC_Trigger=DAC_Trigger_None;
  DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
  DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;
  DAC_Init(DAC_Channel_1, &DAC_InitStructure);

  //DAC_GetDataOutputValue(DAC_Channel_2);

  /*if(mode_dac == SINGLE_DAC1){
	P_DAC1_InitIO();
    P_DAC1_InitDAC();
    
    DAC_SetDAC1(0);  
  }
  else if(mode_dac == SINGLE_DAC2){
	P_DAC2_InitIO();
    P_DAC2_InitDAC();
    
    DAC_SetDAC2(0);   
  }*/
}

void dac::write(){
	
}


void DAC_SetDAC1(uint16_t val)
{
  if(mode_dac==SINGLE_DAC2) return; // wenn nicht erlaubt

  // Max value = 12bit
  if(val>4095) val=4095;

  // DAC1 Wert einstellen (12Bit, rechtsbündig)
  //DAC_SetChannel1Data(DAC_Align_12b_R, val);
}



void DAC_SetDAC2(uint16_t val)
{
  if(mode_dac==SINGLE_DAC1) return; // wenn nicht erlaubt

  // Max value = 12bit
  if(val>4095) val=4095;

  // DAC2 Wert einstellen (12Bit, rechtsbündig)
  //DAC_SetChannel2Data(DAC_Align_12b_R, val);
}

void P_DAC1_InitIO(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;

  // Clock Enable
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

  // Config des DAC-Pins als Analog-Ausgang
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_4;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
}

void P_DAC2_InitIO(void)
{
  GPIO_InitTypeDef  GPIO_InitStructure;

  // Clock Enable
  RCC_AHB1PeriphClockCmd(RCC_AHB1Periph_GPIOA, ENABLE);

  // Config des DAC-Pins als Analog-Ausgang
  GPIO_InitStructure.GPIO_Pin = GPIO_Pin_5;
  GPIO_InitStructure.GPIO_Mode = GPIO_Mode_AN;
  GPIO_InitStructure.GPIO_PuPd = GPIO_PuPd_NOPULL ;
  GPIO_Init(GPIOA, &GPIO_InitStructure);
}


void P_DAC1_InitDAC(void)
{
  DAC_InitTypeDef  DAC_InitStructure;

  // Clock Enable
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

  // DAC-Config
  DAC_InitStructure.DAC_Trigger=DAC_Trigger_None;
  DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
  DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;
  DAC_Init(DAC_Channel_1, &DAC_InitStructure);

  // DAC enable
  DAC_Cmd(DAC_Channel_1, ENABLE);
}

void P_DAC2_InitDAC(void)
{
  DAC_InitTypeDef  DAC_InitStructure;

  // Clock Enable
  RCC_APB1PeriphClockCmd(RCC_APB1Periph_DAC, ENABLE);

  // DAC-Config
  DAC_InitStructure.DAC_Trigger=DAC_Trigger_None;
  DAC_InitStructure.DAC_WaveGeneration = DAC_WaveGeneration_None;
  DAC_InitStructure.DAC_OutputBuffer = DAC_OutputBuffer_Enable;
  DAC_Init(DAC_Channel_2, &DAC_InitStructure);

  // DAC enable
  DAC_Cmd(DAC_Channel_2, ENABLE);
}


// Preinstantiate Objects //////////////////////////////////////////////////////

dac dac1(0);
dac dac2(1);

