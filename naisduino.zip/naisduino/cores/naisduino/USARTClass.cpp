/**
 * @authors Particle Industries, Avik De <avikde@gmail.com>

  This file is part of koduino <https://github.com/avikde/koduino>

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */
#include "stm32f4xx.h"
#include "USARTClass.h"
#include "nvic.h"
#include "pins.h"
#include "system_clock.h"

void configUSARTPins(USART_TypeDef *USARTx, uint8_t txPin, uint8_t rxPin) {
  // Need to check datasheet
  uint8_t af = 0x07;
#if defined(SERIES_STM32F4xx)
  // FIXME: this will need to be expanded
  if (USARTx == USART6 || USARTx == UART4 ||USARTx == UART5 ) {
    af = 8;
  }
#endif
#if defined(SERIES_STM32F30x)
  // FIXME: this will need to be expanded
  if (USARTx == UART4 || USARTx == UART5) {
    af = 5;
  }
#endif
  pinModeAlt(txPin, GPIO_OType_PP, GPIO_PuPd_UP, af);
  pinModeAlt(rxPin, GPIO_OType_PP, GPIO_PuPd_UP, af);
}


// Initialize Class Variables //////////////////////////////////////////////////
USART_InitTypeDef USARTClass::USART_InitStructure;
// bool USARTClass::USARTSerial_Enabled = false;

// Constructors ////////////////////////////////////////////////////////////////

USARTClass::USARTClass(USARTInfo *usartMapPtr) {
  usartMap = usartMapPtr;

  usartMap->rxBuf = &_rxBuf;
  usartMap->txBuf = &_txBuf;

  memset(&_rxBuf, 0, sizeof(RingBuffer));
  memset(&_txBuf, 0, sizeof(RingBuffer));

  // transmitting = false;
  usartMap->rxCallback = NULL;

  irqnPriority = 3;
}

void USARTClass::init(uint32_t baud, uint32_t wordLength, uint32_t parity, uint32_t stopBits) {
  // Enable interrupt (for RXNE)
  nvicEnable(usartMap->irqChannel, irqnPriority);
  
  // Init USART
 
  USART_InitStructure.USART_BaudRate = baud*2;
  USART_InitStructure.USART_WordLength = wordLength;
  USART_InitStructure.USART_Parity = parity;
  USART_InitStructure.USART_StopBits = stopBits;
  USART_InitStructure.USART_HardwareFlowControl = USART_HardwareFlowControl_None;
  USART_InitStructure.USART_Mode = USART_Mode_Rx | USART_Mode_Tx;
  USART_Init(usartMap->USARTx, &USART_InitStructure);

  USART_Cmd(usartMap->USARTx, ENABLE);
}

// Public Methods //////////////////////////////////////////////////////////////

void USARTClass::begin(uint32_t baud, uint8_t config) {
  configUSARTPins(usartMap->USARTx, usartMap->txPin, usartMap->rxPin);

  switch (config) {
    case SERIAL_8N1: init(baud, USART_WordLength_8b, USART_Parity_No, USART_StopBits_1);
    break;
    case SERIAL_8N2: init(baud, USART_WordLength_8b, USART_Parity_No, USART_StopBits_2);
    break;
    case SERIAL_7E1: init(baud, USART_WordLength_8b, USART_Parity_Even, USART_StopBits_1);
    break;
    case SERIAL_8E1: init(baud, USART_WordLength_9b, USART_Parity_Even, USART_StopBits_1);
    break;
    case SERIAL_7E2: init(baud, USART_WordLength_8b, USART_Parity_Even, USART_StopBits_2);
    break;
    case SERIAL_8E2: init(baud, USART_WordLength_9b, USART_Parity_Even, USART_StopBits_2);
    break;
    case SERIAL_7O1: init(baud, USART_WordLength_8b, USART_Parity_Odd, USART_StopBits_1);
    break;
    case SERIAL_8O1: init(baud, USART_WordLength_9b, USART_Parity_Odd, USART_StopBits_1);
    break;
    case SERIAL_7O2: init(baud, USART_WordLength_8b, USART_Parity_Odd, USART_StopBits_2);
    break;
    case SERIAL_8O2: init(baud, USART_WordLength_9b, USART_Parity_Odd, USART_StopBits_2);
    break;
  }

  USART_ClearFlag(usartMap->USARTx, USART_FLAG_RXNE);
  USART_ClearITPendingBit(usartMap->USARTx, USART_IT_RXNE);
  USART_Cmd(usartMap->USARTx, ENABLE);
}

void USARTClass::end() {
  // wait for transmission to end
  flush();
  USART_ITConfig(usartMap->USARTx, USART_IT_RXNE, DISABLE);
  USART_ITConfig(usartMap->USARTx, USART_IT_TXE, DISABLE);
  USART_Cmd(usartMap->USARTx, DISABLE);
  NVIC_DisableIRQ(usartMap->irqChannel);
	// clear any received data
	_rxBuf.head = _rxBuf.tail;
}

void USARTClass::setPins(uint8_t tx, uint8_t rx) {
  usartMap->txPin = tx;
  usartMap->rxPin = rx;
}

int USARTClass::available(void) {
	if(USART_GetFlagStatus(usartMap->USARTx,USART_FLAG_RXNE)==SET){
		return 1;
	}
	else 
		return 0;
	//return (int)(SERIAL_BUFFER_SIZE + _rxBuf.head - _rxBuf.tail) % SERIAL_BUFFER_SIZE;
}

int USARTClass::peek(void) {
	if (_rxBuf.head == _rxBuf.tail)
    // RX is empty
		return -1;
	else
		return _rxBuf.buffer[_rxBuf.tail];
}

int USARTClass::read(void) {
	unsigned char c = USART_ReceiveData(usartMap->USARTx);
	return c;
}

bool USARTClass::writeComplete() {
  // return (_txBuf.head == _txBuf.tail);
  return (USART_GetITStatus(usartMap->USARTx, USART_IT_TXE) == RESET);
}

void USARTClass::flush() {
  // wait for transmission of outgoing data
  while (_txBuf.head != _txBuf.tail);
	// Loop until last frame transmission complete
	while (USART_GetFlagStatus(usartMap->USARTx, USART_FLAG_TC) == RESET);
}

void USARTClass::stopTX() {
  // don't wait for transmission of outgoing data
  USART_ITConfig(usartMap->USARTx, USART_IT_TXE, DISABLE);
  _txBuf.head = _txBuf.tail = 0;
}

void USARTClass::flushInput() {
  _rxBuf.tail = _rxBuf.head;
}

size_t USARTClass::write(uint8_t c) {
	usartMap->USARTx->DR = c;
	while(!(usartMap->USARTx->SR & USART_FLAG_TXE));
	usartMap->USARTx->SR &= ~USART_FLAG_TXE; 
	return 1;
}



 void USARTClass::attachInterrupt(ByteFunc f) {
   usartMap->rxCallback = f;
   USART_ClearFlag(usartMap->USARTx, USART_FLAG_RXNE);
   USART_ClearITPendingBit(usartMap->USARTx, USART_IT_RXNE);
   USART_ITConfig(usartMap->USARTx, USART_IT_RXNE, ENABLE);
   USART_Cmd(usartMap->USARTx, ENABLE);
 }

// void USARTClass::detachInterrupt() {
//   usartMap->rxCallback = NULL;
// }

// CUSTOM FUNCTIONS

uint8_t USARTClass::peekAt(uint8_t pos) {
  return _rxBuf.buffer[(_rxBuf.tail + pos + 1) % SERIAL_BUFFER_SIZE];
}

extern "C" {
// weak definitions
void busHandlerTC(void *busObject) {}
void busHandlerRX(void *busObject, uint8_t byte) {}
}
