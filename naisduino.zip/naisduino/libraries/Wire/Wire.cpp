/**
 * @authors
 
  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */
#include "Wire.h"

// 1000 gives ~600us block in the requestFrom function when the slave is not connected. 10000 gives ~6000us


#if defined(STM32F40_41xxx)
uint8_t SDA1 = PB7;
uint8_t SCL1 = PB6;
uint8_t SDA2 = PB11;
uint8_t SCL2 = PB10;
uint8_t SDA3 = PC9;
uint8_t SCL3 = PA8;
#define WIRE_TIMEOUT 1000
#endif

// Constructors ////////////////////////////////////////////////////////////////

TwoWire::TwoWire(I2C_TypeDef *I2Cx) : I2Cx(I2Cx) {
	setSpeed(WIRE_100K);
}

// Public Methods //////////////////////////////////////////////////////////////

//setSpeed() should be called before begin() else default to 100KHz
void TwoWire::setSpeed(WireClockSpeed clockSpeed) {
  this->clockSpeed = clockSpeed;
}

void TwoWire::stretchClock(bool stretch) {
  I2C_StretchClockCmd(I2Cx, (stretch == true) ? ENABLE : DISABLE);
}

void TwoWire::begin(void) {
  if (I2Cx == I2C1) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C1, ENABLE);
    // setPins?
    pinModeAlt(SCL1, GPIO_OType_OD, GPIO_PuPd_NOPULL, 4);
    pinModeAlt(SDA1, GPIO_OType_OD, GPIO_PuPd_NOPULL, 4);
  }
  else if (I2Cx == I2C2) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C2, ENABLE);
    // setPins?
    pinModeAlt(SCL2, GPIO_OType_OD, GPIO_PuPd_NOPULL, 4);
    pinModeAlt(SDA2, GPIO_OType_OD, GPIO_PuPd_NOPULL, 4);
  }
  else if (I2Cx == I2C3) {
	RCC_APB1PeriphClockCmd(RCC_APB1Periph_I2C3, ENABLE);
	RCC_APB1PeriphResetCmd(RCC_APB1Periph_I2C3, ENABLE);
	RCC_APB1PeriphResetCmd(RCC_APB1Periph_I2C3, DISABLE);
    
    pinModeAlt(SCL3, GPIO_OType_OD, GPIO_PuPd_NOPULL, 4);
    pinModeAlt(SDA3, GPIO_OType_OD, GPIO_PuPd_NOPULL, 4);
  }

  I2C_InitTypeDef I2C_InitStructure;
  
  I2C_InitStructure.I2C_Mode = I2C_Mode_I2C;
  I2C_InitStructure.I2C_AcknowledgedAddress = I2C_AcknowledgedAddress_7bit;
  I2C_InitStructure.I2C_Ack = I2C_Ack_Enable;

  I2C_InitStructure.I2C_DutyCycle = I2C_DutyCycle_2;// or I2C_DutyCycle_16_9
  I2C_InitStructure.I2C_ClockSpeed = clockSpeed;

  I2C_Init(I2Cx, &I2C_InitStructure);
  I2C_Cmd(I2Cx, ENABLE);
}

void TwoWire::begin(uint8_t address) {
  // TODO: slave mode
}

void TwoWire::begin(int address) {
  begin((uint8_t)address);
}

void TwoWire::end() {
  I2C_Cmd(I2Cx, DISABLE);
  I2C_DeInit(I2Cx);
  // put pins back to highZ
  if (I2Cx == I2C1) {
    pinMode(SDA1, INPUT_PULLUP);
    pinMode(SCL1, INPUT_PULLUP);
  } else if (I2Cx == I2C2) {
    pinMode(SDA2, INPUT_PULLUP);
    pinMode(SCL2, INPUT_PULLUP);
  } 
  else if (I2Cx == I2C3) {
    pinMode(SDA3, INPUT_PULLUP);
    pinMode(SCL3, INPUT_PULLUP);
  }
}

// Arduino API ===============================================================


void TwoWire::beginTransmission(uint8_t address) {
  transmitting = true;
  // set address of targeted slave
  txAddress = address;
  // reset tx buffer iterator vars
  // txBufferIndex = 0;
  txBufferLength = 0;
  txBufferFull = false;
}

uint8_t TwoWire::endTransmission(bool stop) {
  // Returns byte, which indicates the status of the transmission:
  // 0:success
  // 1:data too long to fit in transmit buffer
  // 2:received NACK on transmit of address
  // 3:received NACK on transmit of data
  // 4:other error
  static uint32_t timeout;

  if (txBufferFull)
    return 1;

  //Wait until I2C isn't busy
  timeout = WIRE_TIMEOUT;
  while (I2C_GetFlagStatus(I2Cx, I2C_FLAG_BUSY) == SET) {
    if ((timeout--) == 0) return 4;
  }
  // === F1, F4 ===
  I2C_GenerateSTART(I2Cx, ENABLE);

  timeout = WIRE_TIMEOUT;
  while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT))
    if ((timeout--) == 0) return 4;

  I2C_Send7bitAddress(I2Cx, txAddress<<1, I2C_Direction_Transmitter);

  timeout = WIRE_TIMEOUT;
  while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_TRANSMITTER_MODE_SELECTED))
    if ((timeout--) == 0) return 2;

  for (int i=0; i<txBufferLength; ++i) {
    I2C_SendData(I2Cx, txBuffer[i]);

    timeout = WIRE_TIMEOUT;
    while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_TRANSMITTED))
      if ((timeout--) == 0) return 3;
  }

  // Only generate stop if not restarting
  if (stop) {
    I2C_GenerateSTOP(I2Cx, ENABLE);
  }
  return 0;
}

uint8_t TwoWire::requestFrom(uint8_t address, uint8_t quantity, bool stop) {
  static uint32_t timeout;

  if (quantity > WIRE_BUFFER_LENGTH)
    quantity = WIRE_BUFFER_LENGTH;

  rxBufferIndex = rxBufferLength = 0;

  // === F1, F4 ===
  I2C_GenerateSTART(I2Cx, ENABLE);

  timeout = WIRE_TIMEOUT;
  while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_MODE_SELECT))
    if ((timeout--) == 0) return 0;

  I2C_Send7bitAddress(I2Cx, address<<1, I2C_Direction_Receiver);

  timeout = WIRE_TIMEOUT;
  while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_RECEIVER_MODE_SELECTED))
    if ((timeout--) == 0) return 0;

  for (int i = 0; i<quantity; ++i) {
    if (i == quantity-1 && stop) {
      // disabe acknowledge of received data
      // nack also generates stop condition after last byte received
      I2C_AcknowledgeConfig(I2Cx, DISABLE);
      I2C_GenerateSTOP(I2Cx, ENABLE);
    }

    // wait until one byte has been received
    timeout = WIRE_TIMEOUT;
    while (!I2C_CheckEvent(I2Cx, I2C_EVENT_MASTER_BYTE_RECEIVED)) {
      if ((timeout--) == 0) {
        rxBufferLength = i;
        return i;
      }
    }   
    rxBuffer[i] = I2C_ReceiveData(I2Cx);
  }
  // For next time, enable ACK again
  I2C_AcknowledgeConfig(I2Cx, ENABLE);

  rxBufferLength = quantity;
  return rxBufferLength;
}

// must be called in:
// slave tx event callback
// or after beginTransmission(address)
size_t TwoWire::write(uint8_t data) {
  if (transmitting) {
    // in master transmitter mode
    // don't bother if buffer is full
    if (txBufferLength >= WIRE_BUFFER_LENGTH) {
      txBufferFull = true;
      return 0;
    }
    // put byte in tx buffer
    txBuffer[txBufferLength] = data;
    ++txBufferLength;
  } else{
    // in slave send mode
    // reply to master
    // twi_transmit(&data, 1);
  }
  return 1;
}

// must be called in:
// slave tx event callback
// or after beginTransmission(address)
size_t TwoWire::write(const uint8_t *data, size_t quantity) {
  if (transmitting) {
    // in master transmitter mode
    for(size_t i = 0; i < quantity; ++i){
      write(data[i]);
    }
  } else {
    // in slave send mode
    // reply to master
    // twi_transmit(data, quantity);
  }
  return quantity;
}

// must be called in:
// slave rx event callback
// or after requestFrom(address, numBytes)
int TwoWire::available(void) {
  return rxBufferLength - rxBufferIndex;
}

// must be called in:
// slave rx event callback
// or after requestFrom(address, numBytes)
int TwoWire::read(void) {
  int value = -1;
  
  // get each successive byte on each call
  if(rxBufferIndex < rxBufferLength){
    value = rxBuffer[rxBufferIndex];
    ++rxBufferIndex;
  }

  return value;
}

// must be called in:
// slave rx event callback
// or after requestFrom(address, numBytes)
int TwoWire::peek(void) {
  int value = -1;
  
  if(rxBufferIndex < rxBufferLength){
    value = rxBuffer[rxBufferIndex];
  }

  return value;
}

void TwoWire::flush(void) {
  // TODO: to be implemented.

}

// sets function called on slave write
void TwoWire::onReceive( void (*function)(int) ) {
  user_onReceive = function;
}

// sets function called on slave read
void TwoWire::onRequest( void (*function)(void) ) {
  user_onRequest = function;
}

// Preinstantiate Objects //////////////////////////////////////////////////////

TwoWire Wire1(I2C1);
TwoWire Wire2(I2C2);
TwoWire Wire(I2C3);
