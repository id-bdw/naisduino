/**
 * @authors baidhowi

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */
#include "Encoder.h"


#if defined(STM32F40_41xxx)
uint8_t TIM1_ch1 = 18;   //PE9
uint8_t TIM1_ch2 = 16;	 //PE11
uint8_t TIM2_ch1 = 10;	 //PA15
uint8_t TIM2_ch2 = 8;	 //PB3
uint8_t TIM3_ch1 = 13;	 //PB4
uint8_t TIM3_ch2 = 12;	 //PB5
uint8_t TIM4_ch1 = 6;	 //PD12
uint8_t TIM4_ch2 = 4;	 //PD13
uint8_t TIM5_ch1 = 68;	 //PA0
uint8_t TIM5_ch2 = 69;	 //PA1
uint8_t TIM8_ch1 = 2;	 //PC6
uint8_t TIM8_ch2 = 0;	 //PC7
#endif

// Public Methods //////////////////////////////////////////////////////////////
Encoder::Encoder(TIM_TypeDef *TIMx) : TIMx(TIMx){
}

void Encoder::begin( uint8_t _mode) {
  if (TIMx == TIM1) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM1, ENABLE);
    // setPins
    pinModeAlt(TIM1_ch1, GPIO_OType_PP, GPIO_PuPd_UP, 1);
    pinModeAlt(TIM1_ch2, GPIO_OType_PP, GPIO_PuPd_UP, 1);
  }
  else if (TIMx == TIM2) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM2, ENABLE);
    // setPins
    pinModeAlt(TIM2_ch1, GPIO_OType_PP, GPIO_PuPd_UP, 1);
    pinModeAlt(TIM2_ch2, GPIO_OType_PP, GPIO_PuPd_UP, 1);
  }
  else if (TIMx == TIM3) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM3, ENABLE);
    // setPins
    pinModeAlt(TIM3_ch1, GPIO_OType_PP, GPIO_PuPd_UP, 2);
    pinModeAlt(TIM3_ch2, GPIO_OType_PP, GPIO_PuPd_UP, 2);
  }
  else if (TIMx == TIM4) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM4, ENABLE);
    // setPins
    pinModeAlt(TIM4_ch1, GPIO_OType_PP, GPIO_PuPd_UP, 2);
    pinModeAlt(TIM4_ch2, GPIO_OType_PP, GPIO_PuPd_UP, 2);
  }
  else if (TIMx == TIM5) {
    RCC_APB1PeriphClockCmd(RCC_APB1Periph_TIM5, ENABLE);
    // setPins
    pinModeAlt(TIM5_ch1, GPIO_OType_PP, GPIO_PuPd_UP, 2);
    pinModeAlt(TIM5_ch2, GPIO_OType_PP, GPIO_PuPd_UP, 2);
  }
  else if (TIMx == TIM8) {
    RCC_APB2PeriphClockCmd(RCC_APB2Periph_TIM8, ENABLE);
    // setPins
    pinModeAlt(TIM8_ch1, GPIO_OType_PP, GPIO_PuPd_UP, 3);
    pinModeAlt(TIM8_ch2, GPIO_OType_PP, GPIO_PuPd_UP, 3);
  }
   
  TIM_ICInitTypeDef		TIM_ICInitStruct;
  TIM_ICInitStruct.TIM_Channel=TIM_Channel_1;
  TIM_ICInitStruct.TIM_ICPrescaler=TIM_ICPSC_DIV1; 
  TIM_ICInit(TIMx, &TIM_ICInitStruct);
  TIM_ICInitStruct.TIM_Channel=TIM_Channel_2;
  TIM_ICInitStruct.TIM_ICPrescaler=TIM_ICPSC_DIV1; 
  TIM_ICInit(TIMx, &TIM_ICInitStruct);
  //Set AutoReload
  TIM_SetAutoreload(TIMx,0xFFFF);
  //Encoder interface Config
  TIM_EncoderInterfaceConfig(TIMx, _mode, TIM_ICPolarity_Falling, TIM_ICPolarity_Falling);
  //enable counter
  TIM_Cmd(TIMx, ENABLE);
  
}

uint32_t Encoder::getCount(){
	return TIM_GetCounter(TIMx);
}


// Preinstantiate Objects //////////////////////////////////////////////////////

Encoder Encoder1(TIM1);
Encoder Encoder2(TIM2);
Encoder Encoder3(TIM3);
Encoder Encoder4(TIM4);
Encoder Encoder5(TIM5);
Encoder Encoder8(TIM8);
