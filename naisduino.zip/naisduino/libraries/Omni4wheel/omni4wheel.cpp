/**
 * @authors baidhowi

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */
#include "omni4wheel.h"


void omni4wheel::begin(float ll,float rr,float* aa){
  L = ll;
  r_roda = rr;
  a1 = aa[0];
  a2 = aa[1];
  a3 = aa[2];
  a4 = aa[3];
}

void omni4wheel::forwardKinematics(float* out,float v1,float v2,float v3,float v4){
	float w1, w2, w3, w4;
    
    w1 = v1 * r_roda * RADS;	
	w2 = v2 * r_roda * RADS;
	w3 = v3 * r_roda * RADS;
    w4 = v4 * r_roda * RADS;
    
    out[0] = (-w1 * 0.7071 + w2 * 0.7071 + w3 * 0.7071 - w4 * 0.7071);	//vx
    out[1] = (-w1 * 0.7071 - w2 * 0.7071 + w3 * 0.7071 + w4 * 0.7071);	//vy
    out[2] = (w1 + w2 + w3 + w4)/L;										//vt
}
void omni4wheel::inversKinematics(float* out,float vx,float vy,float vt){
	
	out[3] = ((vy*cos(a1/RADS))-(vx*sin(a1/RADS)) + (vt*r_roda))/r_roda / RADS;	//v4
	out[0] = ((vy*cos(a2/RADS))-(vx*sin(a2/RADS)) + (vt*r_roda))/r_roda / RADS;	//v1
	out[1] = ((vy*cos(a3/RADS))-(vx*sin(a3/RADS)) + (vt*r_roda))/r_roda / RADS;	//v2
	out[2] = ((vy*cos(a4/RADS))-(vx*sin(a4/RADS)) + (vt*r_roda))/r_roda / RADS;	//v3	
}


// Preinstantiate Objects //////////////////////////////////////////////////////

omni4wheel omni4;

