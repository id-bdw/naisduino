/**
 * @authors baidhowi

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */
#include "omni3wheel.h"
#include <BasicLinearAlgebra.h>

Matrix<3,3,float> C;

void omni3wheel::begin(float l, float RWheel) {
  L = l;
  rWheel = RWheel;
  float _x=(float)1/L;  
  arr[2][0] = (float)_x;
  arr[2][1] = (float)_x;
  arr[2][2] = (float)_x;
  C = arr;
  Invert(C);
}

void omni3wheel::forwardKinematics(float* out,float w1,float w2,float w3){
	float v1, v2, v3;
	v1 = w1 * rWheel * 3.14;	
	v2 = w2 * rWheel * 3.14;
	v3 = w3 * rWheel * 3.14;

	out[0] = v3 - (v1*0.5) - (v2*0.5); 	//vx
	out[1] = (v1*0.866) - (v2*0.866);  	//vy
	out[2] = (v1 + v2 + v3)/L;			//vt
	
}
void omni3wheel::inversKinematics(float* out,float vx,float vy,float vt){
	float v1, v2, v3;
	v1 = (C(0,0)*vx) + (C(0,1)*vy) + (C(0,2)*vt);
	v2 = (C(1,0)*vx) + (C(1,1)*vy) + (C(1,2)*vt);
	v3 = (C(2,0)*vx) + (C(2,1)*vy) + (C(2,2)*vt);
	
	// v1 = (-0.3333*vx) + (0.5774*vy) + (C(0,2)*vt);
	// v2 = (-0.3333*vx) - (0.5774*vy) + (C(1,2)*vt);
	// v3 = (0.6667*vx) - 0 + (C(2,2)*vt);
	
	out[0] = (v1 / rWheel) / 3.14; //w1
	out[1] = (v2 / rWheel) / 3.14; //w2
	out[2] = (v3 / rWheel) / 3.14; //w3
	
}

// Preinstantiate Objects //////////////////////////////////////////////////////

omni3wheel omni3;
