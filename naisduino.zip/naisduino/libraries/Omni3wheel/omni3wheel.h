/**
 * @authors baidhowi

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */
#ifndef omni3wheel_h
#define omni3wheel_h

#include "Arduino.h"


class omni3wheel
{
protected:
  float L,rWheel;
  float arr[3][3] = {{-0.5,-0.5,1},{0.866,-0.866,0},{0,0,0}};
public:	
  void begin(float,float);
  void forwardKinematics(float* out,float w1,float w2,float w3);
  void inversKinematics(float* out,float vx,float vy,float vt);
};

extern omni3wheel omni3;

#endif

