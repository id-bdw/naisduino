/**
 * @authors Avik De <avikde@gmail.com>

  This file is part of koduino <https://github.com/avikde/koduino>

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */
#ifndef usart_h
#define usart_h

#include <stdint.h>
#include "types.h"

#ifdef __cplusplus
extern "C"{
#endif // __cplusplus


/** @usart cek again
 *  @{
 */


/**
 * @brief Configure a pin before using it.
 * @details This function behaves like the Arduino one, but does more in some cases.
 * 
 * In a few situations, this *MUST* be called in this library when it is not necessary 
 * to in Arduino. For instance, a timer pin must be configured for PWM using 
 * pinMode(pin, PWM) before calling analogWrite() on that pin.
 * 
 */
 
void usart1Config(uint32_t baud);
void usart1Send(unsigned char xx);

#ifdef __cplusplus
} // extern "C"
#endif

#endif
