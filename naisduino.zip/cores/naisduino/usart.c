/**
   @modified baidhowi

  This library is free software; you can redistribute it and/or
  modify it under the terms of the GNU Lesser General Public
  License as published by the Free Software Foundation, either
  version 3 of the License, or (at your option) any later version.

  This library is distributed in the hope that it will be useful,
  but WITHOUT ANY WARRANTY; without even the implied warranty of
  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
  Lesser General Public License for more details.

  You should have received a copy of the GNU Lesser General Public
  License along with this library; if not, see <http://www.gnu.org/licenses/>.
 */
#include "stm32f4xx.h"
#include "pins.h"
#include "timer.h"
#include "exti.h"
#include "usart.h"
#include "variant.h"

// Global variable
//GPIO_InitTypeDef  GPIO_InitStruct;
USART_InitTypeDef USART_InitStructure;

void usart1Config(uint32_t baud){
  pinModeAlt(PB6, GPIO_OType_PP, GPIO_PuPd_UP, 7);
  pinModeAlt(PB7, GPIO_OType_PP, GPIO_PuPd_UP, 7);
  
  USART_OverSampling8Cmd(USART1,DISABLE);
  USART_InitStructure.USART_BaudRate 		= baud;
  USART_InitStructure.USART_WordLength		= USART_WordLength_8b;
  USART_InitStructure.USART_StopBits		= USART_StopBits_1;
  USART_InitStructure.USART_Parity			= USART_Parity_No;
  USART_InitStructure.USART_Mode 				= USART_Mode_Rx | USART_Mode_Tx;
  USART_InitStructure.USART_HardwareFlowControl	= USART_HardwareFlowControl_None;
  USART_Init(USART1,&USART_InitStructure);
  USART_Cmd(USART1,ENABLE);
}
void usart1Send(unsigned char xx){
	USART1->DR = xx;
    while(!(USART1->SR & USART_FLAG_TXE));
    USART1->SR &= ~USART_FLAG_TXE; 
}



